namespace Un4seen.Bass;

public enum BASSStreamProc
{
	STREAMPROC_DUMMY = 0,
	STREAMPROC_PUSH = -1,
	BASS_STREAMPROC_END = int.MinValue
}
