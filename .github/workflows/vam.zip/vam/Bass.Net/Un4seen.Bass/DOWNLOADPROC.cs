using System;

namespace Un4seen.Bass;

public delegate void DOWNLOADPROC(IntPtr buffer, int length, IntPtr user);
