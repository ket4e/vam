using System;

namespace Un4seen.BassWasapi;

public delegate int WASAPIPROC(IntPtr buffer, int length, IntPtr user);
