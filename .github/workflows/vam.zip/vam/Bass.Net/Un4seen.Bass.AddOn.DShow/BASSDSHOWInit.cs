using System;

namespace Un4seen.Bass.AddOn.DShow;

[Flags]
public enum BASSDSHOWInit
{
	BASS_DSHOW_Default = 0,
	BASS_DSHOW_MultiThread = 0x10
}
