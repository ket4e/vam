using System;

[Serializable]
public enum MovementTransferOnJump
{
	None,
	InitTransfer,
	PermaTransfer,
	PermaLocked
}
