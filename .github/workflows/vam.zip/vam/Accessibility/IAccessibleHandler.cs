internal interface IAccessibleHandler
{
}
