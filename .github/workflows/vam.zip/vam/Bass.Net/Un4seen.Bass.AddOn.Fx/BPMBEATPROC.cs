using System;

namespace Un4seen.Bass.AddOn.Fx;

public delegate void BPMBEATPROC(int handle, double beatpos, IntPtr user);
