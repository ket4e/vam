namespace Un4seen.Bass.AddOn.DShow;

public enum BASSDSHOWCapture
{
	BASS_DSHOW_CaptureAudio = 65638,
	BASS_DSHOW_CaptureVideo = 65664
}
