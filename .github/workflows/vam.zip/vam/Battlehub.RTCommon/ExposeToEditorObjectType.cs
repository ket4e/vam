namespace Battlehub.RTCommon;

public enum ExposeToEditorObjectType
{
	Undefined,
	EditorMode,
	PlayMode
}
