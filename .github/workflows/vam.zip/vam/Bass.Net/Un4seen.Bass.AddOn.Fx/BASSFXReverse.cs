namespace Un4seen.Bass.AddOn.Fx;

public enum BASSFXReverse
{
	BASS_FX_RVS_REVERSE = -1,
	BASS_FX_RVS_FORWARD = 1
}
