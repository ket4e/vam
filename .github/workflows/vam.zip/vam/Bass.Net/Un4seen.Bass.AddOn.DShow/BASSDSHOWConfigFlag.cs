namespace Un4seen.Bass.AddOn.DShow;

public enum BASSDSHOWConfigFlag
{
	BASS_DSHOW_VMR7 = 1,
	BASS_DSHOW_VMR9 = 2,
	BASS_DSHOW_VMR7WindowsLess = 3,
	BASS_DSHOW_VMR9WindowsLess = 4,
	BASS_DSHOW_EVR = 5,
	BASS_DSHOW_NULLVideo = 6,
	BASS_DSHOW_NULLAudio = 5170,
	BASS_DSHOW_DefaultAudio = 5171
}
