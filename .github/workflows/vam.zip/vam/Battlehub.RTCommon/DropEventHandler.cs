namespace Battlehub.RTCommon;

public delegate void DropEventHandler();
