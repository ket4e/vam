using System;

namespace Un4seen.Bass.AddOn.Mix;

public delegate void SYNCPROCEX(int handle, int channel, int data, IntPtr user, long offset);
