using System;

namespace Un4seen.Bass;

public delegate void SYNCPROC(int handle, int channel, int data, IntPtr user);
