namespace Un4seen.Bass;

public enum BASS3DAlgorithm
{
	BASS_3DALG_DEFAULT,
	BASS_3DALG_OFF,
	BASS_3DALG_FULL,
	BASS_3DALG_LIGHT
}
