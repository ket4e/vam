using System;

namespace Un4seen.Bass.AddOn.Vst;

public delegate float VST_AEFFECT_GetParameter(IntPtr effect, int index);
