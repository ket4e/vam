namespace Assets.OVR.Scripts;

public class Record
{
	public string category;

	public string message;

	public Record(string cat, string msg)
	{
		category = cat;
		message = msg;
	}
}
