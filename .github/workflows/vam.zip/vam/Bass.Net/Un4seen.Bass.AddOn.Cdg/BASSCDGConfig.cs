namespace Un4seen.Bass.AddOn.Cdg;

public enum BASSCDGConfig
{
	BASS_CDG_USERDRAW = 1002
}
