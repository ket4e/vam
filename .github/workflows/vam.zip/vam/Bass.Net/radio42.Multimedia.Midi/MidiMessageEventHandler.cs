namespace radio42.Multimedia.Midi;

public delegate void MidiMessageEventHandler(object sender, MidiMessageEventArgs e);
