namespace Un4seen.Bass.AddOn.Enc;

public enum BASSEncodeServer
{
	BASS_ENCODE_SERVER_DEFAULT,
	BASS_ENCODE_SERVER_NOHTTP,
	BASS_ENCODE_SERVER_META
}
