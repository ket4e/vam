namespace Un4seen.Bass.AddOn.DShow;

public enum BASSDSHOWConfig
{
	BASS_DSHOW_CONFIG_VideoRenderer = 4096,
	BASS_DSHOW_CONFIG_WindowLessHandle = 4097,
	BASS_DSHOW_CONFIG_WindowLessStreams = 4098,
	BASS_DSHOW_CONFIG_AudioRenderer = 4100,
	BASS_DSHOW_CONFIG_FLOATDSP = 4101
}
