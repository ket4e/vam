using UnityEngine;

public class AnimationPose : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
