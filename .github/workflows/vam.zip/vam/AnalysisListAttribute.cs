using UnityEngine;

public class AnalysisListAttribute : PropertyAttribute
{
}
