namespace Un4seen.Bass.AddOn.Cd;

public enum BASSCDDoor
{
	BASS_CD_DOOR_CLOSE,
	BASS_CD_DOOR_OPEN,
	BASS_CD_DOOR_LOCK,
	BASS_CD_DOOR_UNLOCK
}
