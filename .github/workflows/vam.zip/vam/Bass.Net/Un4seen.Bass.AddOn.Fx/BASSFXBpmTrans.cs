using System;

namespace Un4seen.Bass.AddOn.Fx;

[Obsolete("This enumeration is obsolete; do not use BASS_FX_BPM_Translate.")]
public enum BASSFXBpmTrans
{
	BASS_FX_BPM_TRAN_X2,
	BASS_FX_BPM_TRAN_2FREQ,
	BASS_FX_BPM_TRAN_FREQ2,
	BASS_FX_BPM_TRAN_2PERCENT,
	BASS_FX_BPM_TRAN_PERCENT2
}
