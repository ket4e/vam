namespace Battlehub.RTCommon;

public enum BoundsType
{
	Any,
	Mesh,
	SkinnedMesh,
	Custom,
	None,
	Sprite
}
