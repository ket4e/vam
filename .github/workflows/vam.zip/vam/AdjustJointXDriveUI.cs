using UnityEngine.UI;

public class AdjustJointXDriveUI : UIProvider
{
	public Slider driveAngleSlider;

	public Slider autoDriveSpeedSlider;
}
