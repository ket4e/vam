using System;

namespace Un4seen.Bass.AddOn.Enc;

public delegate void ENCODENOTIFYPROC(int handle, BASSEncodeNotify status, IntPtr user);
