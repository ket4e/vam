using UnityEngine.UI;

public class AdjustJointSpringsControlUI : UIProvider
{
	public Slider springStrengthSlider;
}
