namespace Un4seen.BassAsio;

public enum BassAsioHandlerSyncType
{
	SourceStalled,
	SourceResumed,
	BufferUnderrun
}
