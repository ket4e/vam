using System;

namespace Un4seen.Bass.AddOn.Sfx;

[Flags]
public enum BASSSFXFlag
{
	BASS_SFX_DEFAULT = 0,
	BASS_SFX_SONIQUE_OPENGL = 1,
	BASS_SFX_SONIQUE_OPENGL_DOUBLEBUFFER = 2
}
