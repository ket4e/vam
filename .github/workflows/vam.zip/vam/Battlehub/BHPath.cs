namespace Battlehub;

public class BHPath
{
	public const string Root = "Battlehub";
}
