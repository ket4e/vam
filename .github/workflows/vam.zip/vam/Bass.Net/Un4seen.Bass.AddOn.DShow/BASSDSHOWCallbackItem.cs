namespace Un4seen.Bass.AddOn.DShow;

public enum BASSDSHOWCallbackItem
{
	BASS_DSHOW_CALLBACK_AC = 1,
	BASS_DSHOW_CALLBACK_VC,
	BASS_DSHOW_CALLBACK_AR
}
