namespace Un4seen.Bass.AddOn.Wma;

public enum BASSWMAEncodeCallback
{
	BASS_WMA_ENCODE_HEAD,
	BASS_WMA_ENCODE_DATA,
	BASS_WMA_ENCODE_DONE
}
