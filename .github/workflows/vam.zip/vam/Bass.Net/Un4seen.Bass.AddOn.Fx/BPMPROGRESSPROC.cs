using System;

namespace Un4seen.Bass.AddOn.Fx;

public delegate void BPMPROGRESSPROC(int channel, float percent, IntPtr user);
