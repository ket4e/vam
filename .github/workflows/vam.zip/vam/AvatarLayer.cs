using System;

[Serializable]
public class AvatarLayer
{
	public int layerIndex;
}
