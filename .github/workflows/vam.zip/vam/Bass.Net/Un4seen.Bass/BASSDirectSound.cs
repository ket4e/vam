namespace Un4seen.Bass;

public enum BASSDirectSound
{
	BASS_OBJECT_DS = 1,
	BASS_OBJECT_DS3DL
}
