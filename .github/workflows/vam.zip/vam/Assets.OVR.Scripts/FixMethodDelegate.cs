using UnityEngine;

namespace Assets.OVR.Scripts;

public delegate void FixMethodDelegate(Object obj, bool isLastInSet, int selectedIndex);
