using System;

namespace Un4seen.Bass.AddOn.Fx;

public delegate void BPMPROC(int handle, float bpm, IntPtr user);
