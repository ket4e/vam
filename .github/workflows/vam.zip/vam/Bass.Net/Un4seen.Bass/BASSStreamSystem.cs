namespace Un4seen.Bass;

public enum BASSStreamSystem
{
	STREAMFILE_NOBUFFER,
	STREAMFILE_BUFFER,
	STREAMFILE_BUFFERPUSH
}
