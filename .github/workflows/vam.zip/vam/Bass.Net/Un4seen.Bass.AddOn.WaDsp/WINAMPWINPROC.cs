using System;

namespace Un4seen.Bass.AddOn.WaDsp;

public delegate int WINAMPWINPROC(IntPtr hwnd, int msg, int wParam, int lParam);
