using UnityEngine;

public class AnimationPoseJoint : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
