namespace Un4seen.Bass.AddOn.DShow;

public enum BASSDSHOWDVDMenu
{
	BASS_DSHOW_DVDSelectAtPos = 21,
	BASS_DSHOW_DVDActionAtPos,
	BASS_DSHOW_DVDActivateButton,
	BASS_DSHOW_DVDSelectButton
}
