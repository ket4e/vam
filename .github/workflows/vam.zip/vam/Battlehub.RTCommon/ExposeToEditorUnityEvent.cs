using System;
using UnityEngine.Events;

namespace Battlehub.RTCommon;

[Serializable]
public class ExposeToEditorUnityEvent : UnityEvent<ExposeToEditor>
{
}
