namespace Un4seen.Bass.AddOn.Midi;

public enum BASSMIDISystem
{
	MIDI_SYSTEM_DEFAULT,
	MIDI_SYSTEM_GM1,
	MIDI_SYSTEM_GM2,
	MIDI_SYSTEM_XG,
	MIDI_SYSTEM_GS
}
