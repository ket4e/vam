using System;

namespace Un4seen.BassAsio;

public delegate void ASIONOTIFYPROC(BASSASIONotify notify, IntPtr user);
