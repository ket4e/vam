namespace Un4seen.Bass.AddOn.Enc;

public enum BASSEncodeStats
{
	BASS_ENCODE_STATS_SHOUT,
	BASS_ENCODE_STATS_ICE,
	BASS_ENCODE_STATS_ICESERV
}
