namespace radio42.Multimedia.Midi;

public enum MIDIManufacturer : byte
{
	Extended = 0,
	Educational = 125,
	RealTime = 127,
	NonRealTime = 126
}
