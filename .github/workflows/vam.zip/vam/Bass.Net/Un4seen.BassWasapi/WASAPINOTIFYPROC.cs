using System;

namespace Un4seen.BassWasapi;

public delegate void WASAPINOTIFYPROC(BASSWASAPINotify notify, int device, IntPtr user);
