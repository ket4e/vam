namespace Battlehub.RTCommon;

public delegate void BeginDragEventHandler();
