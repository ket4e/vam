namespace Un4seen.BassWasapi;

public enum BassWasapiHandlerSyncType
{
	SourceStalled,
	SourceResumed
}
