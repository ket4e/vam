namespace Battlehub.RTCommon;

public delegate void ExposeToEditorEvent(ExposeToEditor obj);
