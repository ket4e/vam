namespace Battlehub.RTCommon;

public delegate void GameCameraEvent();
