namespace Battlehub.RTCommon;

public delegate bool ApplyCallback(Record record);
