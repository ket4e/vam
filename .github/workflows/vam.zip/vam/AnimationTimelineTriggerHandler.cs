public interface AnimationTimelineTriggerHandler
{
	float GetCurrentTimeCounter();

	float GetTotalTime();
}
