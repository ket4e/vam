namespace Un4seen.Bass.AddOn.Cd;

public enum BASSCDDATAType
{
	BASS_CD_DATA_SUBCHANNEL,
	BASS_CD_DATA_C2
}
