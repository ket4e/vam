namespace Un4seen.Bass.AddOn.Sfx;

public enum BASSSFXPlugin
{
	BASS_SFX_SONIQUE = 0,
	BASS_SFX_WINAMP = 1,
	BASS_SFX_WMP = 2,
	BASS_SFX_BBP = 3,
	BASS_SFX_UNKNOWN = -1
}
