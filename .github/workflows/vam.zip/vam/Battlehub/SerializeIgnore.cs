using System;

namespace Battlehub;

public class SerializeIgnore : Attribute
{
}
