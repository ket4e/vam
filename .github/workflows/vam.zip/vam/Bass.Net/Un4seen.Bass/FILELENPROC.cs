using System;

namespace Un4seen.Bass;

public delegate long FILELENPROC(IntPtr user);
