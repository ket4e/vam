namespace Un4seen.Bass.AddOn.DShow;

public enum BASSDSHOWDVDGetProperty
{
	BASS_DSHOW_CurentDVDTitle = 65552,
	BASS_DSHOW_DVDTitles = 65568,
	BASS_DSHOW_DVDTitleChapters = 65584,
	BASS_DSHOW_DVDCurrentTitleDuration = 145,
	BASS_DSHOW_DVDCurrentTitlePosition = 146
}
