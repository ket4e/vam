namespace Un4seen.Bass.AddOn.Tags;

public enum TAGINFOEncoding
{
	Ansi,
	Latin1,
	Utf8,
	Utf8OrLatin1
}
