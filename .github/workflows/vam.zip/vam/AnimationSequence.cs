using UnityEngine;

public class AnimationSequence : MonoBehaviour
{
	public Transform animatedTransform;
}
