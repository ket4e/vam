using System;

namespace Un4seen.Bass.AddOn.DShow;

public delegate void VIDEOSYNCPROC(int channel, BASSDSHOWSync sync, int data, IntPtr user);
