using System;

namespace Un4seen.Bass.AddOn.Sfx;

[Serializable]
internal struct BASS_SFX_PLUGININFO_INTERNAL
{
	public IntPtr name;

	public IntPtr clsid;
}
