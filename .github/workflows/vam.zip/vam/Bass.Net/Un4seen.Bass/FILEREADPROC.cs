using System;

namespace Un4seen.Bass;

public delegate int FILEREADPROC(IntPtr buffer, int length, IntPtr user);
