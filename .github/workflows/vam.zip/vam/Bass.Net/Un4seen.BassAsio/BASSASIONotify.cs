namespace Un4seen.BassAsio;

public enum BASSASIONotify
{
	BASS_ASIO_NOTIFY_RATE = 1,
	BASS_ASIO_NOTIFY_RESET
}
