namespace Un4seen.Bass.AddOn.Vst;

public enum BASSVSTAction
{
	BASS_VST_PARAM_CHANGED = 1,
	BASS_VST_EDITOR_RESIZED,
	BASS_VST_AUDIO_MASTER
}
