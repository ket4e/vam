using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("BASS.NET API for .Net")]
[assembly: AssemblyDescription("BASS.NET API for the Un4seen Bass Audio Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("radio42")]
[assembly: AssemblyProduct("BASS.NET")]
[assembly: AssemblyCopyright("Copyright © 2005-2016 by radio42: Bernd Niedergesaess, Germany. http://www.bass.radio42.com/ - bn@radio42.com")]
[assembly: AssemblyTrademark("See http://www.bass.radio42.com and http://www.un4seen.com for details.")]
[assembly: CLSCompliant(true)]
[assembly: AllowPartiallyTrustedCallers]
[assembly: AssemblyFileVersion("2.4.13.2")]
[assembly: AssemblyVersion("2.4.13.2")]
