namespace Battlehub.RTCommon;

public interface IGL
{
	void Draw(int cullingMask);
}
