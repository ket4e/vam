namespace Un4seen.Bass.AddOn.Cd;

public enum BASSCDInterface
{
	BASS_CD_IF_AUTO,
	BASS_CD_IF_SPTI,
	BASS_CD_IF_ASPI,
	BASS_CD_IF_WIO,
	BASS_CD_IF_LINUX
}
