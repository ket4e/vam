using UnityEngine.UI;

public class AnimatedDAZBoneDirectDrivesUI : UIProvider
{
	public Toggle onToggle;
}
