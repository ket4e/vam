namespace Un4seen.Bass.AddOn.Wma;

public enum BASSWMATag
{
	BASS_WMA_TAG_ANSI = 0,
	BASS_WMA_TAG_UNICODE = 1,
	BASS_WMA_TAG_UTF8 = 2,
	BASS_WMA_TAG_BINARY = 0x100
}
