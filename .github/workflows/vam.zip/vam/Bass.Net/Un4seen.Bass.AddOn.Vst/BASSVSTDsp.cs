using System;

namespace Un4seen.Bass.AddOn.Vst;

[Flags]
public enum BASSVSTDsp
{
	BASS_VST_DEFAULT = 0,
	BASS_VST_KEEP_CHANS = 1,
	BASS_UNICODE = int.MinValue
}
