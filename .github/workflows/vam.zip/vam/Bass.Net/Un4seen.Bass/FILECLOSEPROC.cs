using System;

namespace Un4seen.Bass;

public delegate void FILECLOSEPROC(IntPtr user);
