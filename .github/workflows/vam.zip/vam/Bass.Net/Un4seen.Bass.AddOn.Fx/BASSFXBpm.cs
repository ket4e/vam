namespace Un4seen.Bass.AddOn.Fx;

public enum BASSFXBpm
{
	BASS_FX_BPM_DEFAULT = 0,
	BASS_FX_BPM_BKGRND = 1,
	BASS_FX_BPM_MULT2 = 2,
	BASS_FX_FREESOURCE = 0x10000
}
