using System;

namespace Un4seen.Bass.AddOn.Winamp;

[Flags]
public enum BASSWINAMPFindPlugin
{
	BASS_WINAMP_FIND_INPUT = 1,
	BASS_WINAMP_FIND_RECURSIVE = 4,
	BASS_WINAMP_FIND_COMMALIST = 8
}
