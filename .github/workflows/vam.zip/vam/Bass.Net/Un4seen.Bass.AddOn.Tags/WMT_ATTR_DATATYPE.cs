namespace Un4seen.Bass.AddOn.Tags;

internal enum WMT_ATTR_DATATYPE : ushort
{
	WMT_TYPE_DWORD,
	WMT_TYPE_STRING,
	WMT_TYPE_BINARY,
	WMT_TYPE_BOOL,
	WMT_TYPE_QWORD,
	WMT_TYPE_WORD,
	WMT_TYPE_GUID
}
