namespace Un4seen.Bass.Misc;

public delegate void BroadCastEventHandler(object sender, BroadCastEventArgs e);
